pub const app_version = "0.2.10";
